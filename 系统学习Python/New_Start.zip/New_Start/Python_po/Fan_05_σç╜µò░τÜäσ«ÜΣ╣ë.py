# 函数必须先定义后使用
def hello():
    print("1")
    print("2")
    print("3")

hello()


# 给函数增加文档注释


def mmd():
    """mmd"""
    print("mmd")