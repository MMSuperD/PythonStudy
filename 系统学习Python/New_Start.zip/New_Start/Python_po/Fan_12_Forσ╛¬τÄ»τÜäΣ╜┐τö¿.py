
# TODO(Fan) for 循环的语法 和使用


for number in [1,2,3,4]:
    print(number)

else:
    print("end")