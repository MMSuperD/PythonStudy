
num_list = ["12","14"]

num_tuple = tuple(num_list)

new_list = list(num_tuple)

print(num_tuple)
print(new_list)