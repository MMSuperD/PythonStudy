import random

rd = random.randint(1,3)

# type(random.randint(1,3)) 检查类型

print(rd)