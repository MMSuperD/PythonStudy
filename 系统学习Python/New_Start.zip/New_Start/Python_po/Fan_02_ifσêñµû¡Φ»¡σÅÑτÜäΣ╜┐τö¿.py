# 1.定义一个整数变量记录年龄
age = 13
age = int(input("请你输入年龄:"))

# 2. 判断是否满了18岁
if age >= 18:
    print("你已经成年,可以到网吧嗨皮了")

    print("I am very well")

elif age >= 13:
    print("你可以打球了")

else:
    print("你还没有成年")