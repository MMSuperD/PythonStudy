# *_* coding:utf8 *_*

text = u"hello 世界"   # 字符串前面加上u 这个字符 可以告诉解释器使用utf8 来解释了

print(text)