
text = input("请输入算术题:")
print(eval(text))  # eval()函数就相当于一个小型的计数器