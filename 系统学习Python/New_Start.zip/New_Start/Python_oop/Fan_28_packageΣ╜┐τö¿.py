import fan_package

fan_package.recive_message.receive()

