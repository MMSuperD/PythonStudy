
def receive():
    return "接收到消息"
