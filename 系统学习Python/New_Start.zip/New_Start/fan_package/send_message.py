def send(text):
    print("正在发送内容: %s" % str(text))
