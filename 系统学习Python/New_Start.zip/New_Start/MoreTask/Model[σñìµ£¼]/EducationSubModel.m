//
//  EducationSubModel.m
//  BalanceTransfer
//
//  Created by HeCode on 2018/3/23.
//  Copyright © 2018年 tlsw. All rights reserved.
//

#import "EducationSubModel.h"

@implementation EducationSubModel

@end
