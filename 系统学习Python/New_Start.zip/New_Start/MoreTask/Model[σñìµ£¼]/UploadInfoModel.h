//
//  UploadInfoModel.h
//  BalanceTransfer
//
//  Created by HeCode on 2018/3/14.
//  Copyright © 2018年 tlsw. All rights reserved.
//

#import "BaseModel.h"

@interface UploadInfoModel : BaseModel

@property (nonatomic, copy) NSString *portraitImg;

@end
