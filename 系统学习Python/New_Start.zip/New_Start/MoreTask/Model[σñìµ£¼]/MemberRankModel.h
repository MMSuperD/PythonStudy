//
//  MemberRankModel.h
//  BalanceTransfer
//
//  Created by zhangmeijia on 2019/4/9.
//  Copyright © 2019 tlsw. All rights reserved.
//

#import "BaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MemberRankModel : BaseModel

@property (nonatomic, assign) NSInteger rank;

@end

NS_ASSUME_NONNULL_END
