//
//  HelpCenterQuestionModel.h
//  BalanceTransfer
//
//  Created by zhangmeijia on 2019/3/12.
//  Copyright © 2019 tlsw. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HelpCenterQuestionModel : NSObject

@property (nonatomic, strong) NSString *question;
@property (nonatomic, strong) NSString *answer;

@end

NS_ASSUME_NONNULL_END
