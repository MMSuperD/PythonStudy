//
//  BTSmsSignModel.h
//  BalanceTransfer
//
//  Created by zhangmeijia on 2019/3/5.
//  Copyright © 2019 tlsw. All rights reserved.
//

#import "BaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BTSmsSignModel : BaseModel

@property (nonatomic, strong) NSString *smsSignNo;

@end

NS_ASSUME_NONNULL_END
