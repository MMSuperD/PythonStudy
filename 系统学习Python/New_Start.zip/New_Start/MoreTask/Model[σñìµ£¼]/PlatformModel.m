//
//  PlatformModel.m
//  BalanceTransfer
//
//  Created by zhangmeijia on 2018/3/25.
//  Copyright © 2018年 tlsw. All rights reserved.
//

#import "PlatformModel.h"

@implementation PlatformModel

@end
