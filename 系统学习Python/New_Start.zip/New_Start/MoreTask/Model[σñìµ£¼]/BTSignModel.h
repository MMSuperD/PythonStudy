//
//  BTSignModel.h
//  BalanceTransfer
//
//  Created by zhangmeijia on 2018/11/6.
//  Copyright © 2018 tlsw. All rights reserved.
//

#import "BaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BTSignModel : BaseModel

@property (nonatomic, strong) NSString *sdkUrl;

@end

NS_ASSUME_NONNULL_END
