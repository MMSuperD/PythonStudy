//
//  MapSupModel.h
//  BalanceTransfer
//
//  Created by HeCode on 2018/3/23.
//  Copyright © 2018年 tlsw. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MapSupModel : NSObject

@property (strong, nonatomic) NSString *createTime;
@property (strong, nonatomic) NSString *advancedId;
@property (strong, nonatomic) NSString *infoKey;
@property (strong, nonatomic) NSString *infoValue;
@property (strong, nonatomic) NSString *memberId;
@property (strong, nonatomic) NSString *status;
@property (strong, nonatomic) NSString *updateTime;
@property (strong, nonatomic) NSString *updatorId;
@property (strong, nonatomic) NSString *infoTitle;

@end
